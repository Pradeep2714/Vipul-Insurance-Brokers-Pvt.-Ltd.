# Vipul Insurance Android Demo - phone-only GitHub build

This is a sample-data prototype, not a production insurance application.

1. Create a PRIVATE GitHub repository named `vipul-insurance-android` with a `main` branch.
2. Extract this ZIP. Upload all files at the repository root, including the hidden `.github/workflows/android-apk.yml` file. Do not upload the outer folder itself.
3. On GitHub open Actions > Build Vipul Android APK > Run workflow, or push to `main` to start automatically.
4. After success open the run > Artifacts > vipul-insurance-debug-apk. Download, extract the ZIP, and install `app-debug.apk` on Android.

The workflow runs `npm install`, `npm run build`, creates the Capacitor Android project and compiles a signed debug APK in GitHub Actions. This build has not been executed here and may need adjustments if the remote toolchain changes.

Do not use real customer information. The prototype uses local browser storage, mock data, a scripted chatbot, and has no real authentication or insurer/payment/health APIs.
